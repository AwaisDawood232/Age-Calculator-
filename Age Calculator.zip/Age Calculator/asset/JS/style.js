

// Here we will access everything which we want to change


const ageValue = document.getElementById("ageValue");
const currentAge = document.getElementById("current_Age");
const calculateAge = document.getElementById("calculateAge");
const DOB = document.getElementById("DOB");
const InYears = document.getElementById("InYears");
const InMonths = document.getElementById("InMonth");
const InWeeks = document.getElementById("InWeeks");
const InDays = document.getElementById("InDays");
const InHours = document.getElementById("InHours");
const InMinutes = document.getElementById("InMinutes");
const InSeconds = document.getElementById("InSeconds");
const DaysLeft = document.getElementById("DaysLeft");


// To calculate DOB we add some operation 
const today = new Date();
const seconds = 1000; // here we get milliseconds
const minutes = 60;
const hours = 24;
const week = 7;

// Here we convert our date into ISO Standard time then use substring to give us only date of 10 digits like (2024-01-0=10)
let maxDate = today.toISOString().substring(0,10); 
// Now we use attribute to ageValue Input that user cannot access future date
ageValue.setAttribute("max", maxDate);


calculateAge.addEventListener("click", function(event)  {
  if(ageValue.value === maxDate){
    alert("Invalid Date of Birth");
  }


// Here we declare days, hours or minutes 
let oneDay = seconds * minutes * minutes * hours;
let oneHour = seconds * minutes * minutes;
let oneMinutes = seconds * minutes;

// Now we input from user and put it in birthDay variable
let birthDay = new Date(ageValue.value);

if(ageValue.value !== ""){
  
  // Here we Get Year by doing this small operation
  let TotalYears = today.getFullYear() - birthDay.getFullYear() - (today.getMonth() < birthDay.getMonth() || (today.getMonth() === birthDay.getMonth() && today.getDate() < birthDay.getDate() ));

  let TotalMonths = today.getMonth() - birthDay.getMonth() + (today.getFullYear() - birthDay.getFullYear()) * 12;

  let MonthsTotal = Math.abs(birthDay.getMonth() - today.getMonth());
  let DaysTotal = Math.abs(today.getDate() - birthDay.getDate());
  
  // here we use .getTime to find time in time in millisecond then convert to days 
  let TotalDays = Math.round(
    Math.abs(today.getTime() - birthDay.getTime()) / oneDay
  );

  let TotalWeeks = Math.round(
    Math.abs(today.getTime() - birthDay.getTime()) / (oneDay * week)
  );

  let TotalHours = Math.round(
    Math.abs(today.getTime() - birthDay.getTime()) / oneHour
  );

  let TotalMinutes = Math.round(
    Math.abs(today.getTime() - birthDay.getTime()) / oneMinutes
  );

  let TotalSeconds = Math.round(
    Math.abs(today.getTime() - birthDay.getTime()) / seconds
  );

  currentAge.innerText = `${TotalYears} Years ${MonthsTotal} Months ${DaysTotal} Days`;
  DOB.innerText = ` ${birthDay.toLocaleString("default", {
    weekday: "long",
  })} ${birthDay.toLocaleString("default", {
    month: "long",
  })}, ${birthDay.getDate()}, ${birthDay.getFullYear()} `;


  InYears.innerText = TotalYears;
    InMonths.innerText = TotalMonths;
    InWeeks.innerText = TotalWeeks;
    InDays.innerText = TotalDays;
    InHours.innerText = TotalHours;
    InMinutes.innerText = TotalMinutes;
    InSeconds.innerText = TotalSeconds;


    let birthDayThisYear = new Date(
      `${today.getFullYear()}-${birthDay.getMonth() + 1}-${birthDay.getDate()}`
      );
      if (today > birthDayThisYear) {
          birthDayThisYear.setFullYear(today.getFullYear() + 1);
      }

    let TotalDaysLeft = Math.round(
      Math.abs(birthDayThisYear.getTime() - today.getTime()) / oneDay
    );

    DaysLeft.innerText = TotalDaysLeft;
}

});